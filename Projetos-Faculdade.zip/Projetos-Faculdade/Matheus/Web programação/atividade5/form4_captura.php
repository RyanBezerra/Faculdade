<?php

    $nome = $_GET["nome"];
    $ultimo_nome = $_GET["ultimo_nome"];
    $email = $_GET["email"];
    $sexo = $_GET["sexo"];

    echo $nome. " " . $ultimo_nome. " " . $email . " " . $sexo;
    


?>



