<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            text-align: center;
        }
    </style>
    <title>Pagina</title>
</head>
<body>
    <h1><strong>Employee Login Form</strong></h1>
    <form action="">
        <p>Primeiro Nome:<input type="text" name="Primerio"/></p>
        <p>Ultimo Nome:<input type="text" name="Ultimo"/></p>
        <p>Email:<input type="email" name="Email"/></p>
        <p><input type="radio">Homem</p>
        <p><input type="radio">Mulher</p>
        <input type="submit" value="submit">
        <input type="submit" value="reset">
        
    </form>
</body>
</html>