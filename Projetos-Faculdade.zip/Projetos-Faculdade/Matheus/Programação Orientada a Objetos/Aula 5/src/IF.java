
public class IF {

	public static void main(String[] args) {
		
		double n1 = 10;
		double n2 = 3;
		double resultado = n1/n2;
		
		
		System.out.printf("O resultado  é : %.2f", resultado);
		
		System.out.println("\n"+resultado);	

	}

}
