#include <stdio.h>


int main ()
{	
	float R;
	float A;
	
	printf("Digite o raio: \n");
	scanf("%f", &R);
	A = 3.14159 * (R * R);
	printf("%f",A);
	

	return 0;
	
}