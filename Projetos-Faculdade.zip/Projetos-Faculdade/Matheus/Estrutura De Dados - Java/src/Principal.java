
public class Principal {
	
public static void main(String[]args) {
	Lista ListaSequencial = new Lista();
	
	System.out.println("A lista esta vazia?"+ ListaSequencial.EstaVazia());
	System.out.println("A lista esta cheia?"+ ListaSequencial.EstaCheia());
	System.out.println("A lista tem:"+ ListaSequencial.tamanhoLista() + " elementos");
	
	//Parte2
	//Criando objetos

Contato c1 = new Contato();
	c1.NOME="Matheus";
	c1.TELEFONE="9842-9292";
			
Contato c2 = new Contato();
	c2.NOME="Ryan";
	c2.TELEFONE="1111-1111";
	
	Contato c3 = new Contato();
	c3.NOME="Ryan";
	c3.TELEFONE="1111-1111";
	
	Contato c4 = new Contato();
	c4.NOME="Walace";
	c4.TELEFONE="1111-1111";
	
	//Inserindo objetos na lista sequencial
	
	ListaSequencial.inserirContato(0, c1);
	ListaSequencial.inserirContato(0, c2);
	ListaSequencial.inserirContato(0, c3);
	ListaSequencial.inserirContato(0, c4);
	
	//Exibindo lista
	
	ListaSequencial.exibirLista();
	
	//Removendo o elemento da primeira posição
	
	ListaSequencial.remover(0);
	
	//Buscar posição do elemento
	
	System.out.println("\nNome do elemento da terceira posicao e: "+ ListaSequencial.buscar(2).NOME);
	
	//Buscar posição do elemento c2 (Ryan)
	
	System.out.println("\nPosicao do contato de Ryan e:"+ ListaSequencial.retornarPosicao(c2));
			
}
}