<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {font-family: Arial, Helvetica, sans-serif;}
    </style>
    <title>Pagina</title>
</head>
<body>
    <h1><strong>Formulário de Inscrição</strong></h1>
    <h2><strong>Preencha os dados</strong></h2>
    <form action="">
        <p>Nome:<input type="text" name="Nome" /></p>
        <p>E-mail:<input type="email" name="E-mail" /></p>
        <p>Endereço:<input type="text" name="Endereço" /></p>
        <p>Cidade:<input type="text" name="Cidade" /></p>
        <p>Telefone:<input type="text" name="Telefone" /><input type="text" name="Telefone"</p>
        <p>Usuário:<input type="Usuário" name="Usuário" value="Entre com seu login" /></p>
        <p>Senha:<input type="password" name="Senha" /></p>
        <input type="submit" value="Finalizar minha inscrição">
        
    </form>
</body>
</html>