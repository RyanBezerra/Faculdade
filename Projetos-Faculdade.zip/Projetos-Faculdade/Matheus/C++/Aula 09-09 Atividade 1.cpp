#include <stdio.h>

int main()
{
	
	int n;
	
	printf("tabela de ASCII: \n");
	
	for(n = 32;n< 77;n++)
	
	printf("Caractere: %c Codigo: %d\n",n,n);

return 0;
	
}