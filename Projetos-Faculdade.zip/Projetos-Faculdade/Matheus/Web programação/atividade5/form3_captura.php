<?php

    $usarname = $_POST["usarname"];
    $password = $_POST["password"];

    echo "Usarname: " .$usarname . "e " . "Password: " .$password . " digitados";
     
   

?>