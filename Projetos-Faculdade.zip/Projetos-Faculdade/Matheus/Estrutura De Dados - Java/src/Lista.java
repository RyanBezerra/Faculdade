
public class Lista {
	Contato[] contatos = new Contato[100];
	int tamanho = 0;
	
	public boolean EstaVazia() {
		return (tamanho==0);
	}
	
	public boolean EstaCheia() {
		return (tamanho==contatos.length);
	}
	
	public int tamanhoLista() {
		return tamanho;
	}

	public Contato buscar(int pos) {
		//Verificar se a variavel posição procurada é valida
		if( (pos >= tamanho ) || (pos < 0) ) {
			return null; 
		}
		return contatos[pos];
	}
	
	public boolean compara(Contato c1, Contato c2) {
		return (c1.NOME.equals(c2.NOME) ) &&
				(c1.TELEFONE.equals(c2.TELEFONE) );
	}
	
	public int retornarPosicao(Contato contato) {
		for (int i=0; i < tamanho; i++)
			if (compara(contatos[i], contato))
				return i; 
		return -1;
			
	}
	
	public void deslocarParaDireita(int pos) {
		for (int i = tamanho ; i > pos; i--)
			contatos[i] = contatos[ i -1];
	}
	
	public boolean inserirContato (int pos, Contato c1) {
		if(EstaCheia() || (pos > tamanho) || (pos < 0) )
			return false; 
		deslocarParaDireita(pos);
		contatos[pos] = c1;
		tamanho++;
		return true;
	}
	
	public void deslocarParaEsquerda(int pos) {
		for (int i = pos; i < (tamanho -1); i++)
			contatos[i] = contatos[i+1];
	}
	
	public boolean remover (int pos) {
		if ( (pos >=tamanho) || (pos < 0) )
			return false;
		deslocarParaEsquerda(pos);
		tamanho--;
		return true;
	}	
	
	public void exibirLista() {
		for (int i=0; i<tamanho; i++) {
			System.out.println("\nContato"+(i+1)+ "\nNome: "
					+contatos[i].NOME
					+"\nTelefone:"
					+contatos[i].TELEFONE);
		}
	}
}