#include <stdio.h>

int main()
{
int i;
	while(1)
{
printf(" abcedario ");
i++;
}
}