<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Formulário 3</title>
    
</head>
<body>
    <h1>Employee Login Form</h1>
    
    <form action="form3_captura.php" method="POST">
        <label for="">UserName</label>
        <input type="text" name="usarname">
        <br>
        <label for="">Password</label>
        <input type="password" name="password">
        <br>
        <input type="submit" value="Submit">
    </form>
    
</body>
</html>