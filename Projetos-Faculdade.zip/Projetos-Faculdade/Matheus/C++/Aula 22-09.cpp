#include <stdio.h>

int main () {
	
	char nome;
	int num[5] [5];
	float media[5];
	char i;
	
	printf("Digite o nome do aluno: \n");
	scanf("%s", &nome);
	
	printf("Digite a media do aluno: \n");
	scanf("%f", &media[4]);
	
	printf("Deseja fazer outra media, apos esta? (s/n)");
	scanf("%s", &i);
	
	
	
	while (1 == 's');

}
