
public class Contato {
	
	String NOME;
	String TELEFONE;
	
	public String getNome() {
			return NOME;
	}
	public void setNome(String NOME) {
			this.NOME = NOME;
	}
	public String getTelefone() {
			return TELEFONE;
	}
	public void setTelefone(String TELEFONE) {
			this.TELEFONE = TELEFONE;
	}
	
}
